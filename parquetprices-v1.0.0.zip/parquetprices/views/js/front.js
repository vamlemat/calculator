/**
 * Parquet Prices Display - Frontend JavaScript
 * @author ATECH
 * @version 1.0.0
 */

(function() {
    'use strict';

    /**
     * Inicializa el módulo cuando el DOM está listo
     */
    function initParquetPrices() {
        // Marcar el body si hay precios de parquet activos
        const unitPriceElements = document.querySelectorAll('.parquet-unit-price-main');
        
        if (unitPriceElements.length > 0) {
            document.body.classList.add('has-parquet-prices');
        }

        // Log para debug (opcional, se puede quitar en producción)
        if (window.console && unitPriceElements.length > 0) {
            console.log('[Parquet Prices] Módulo activo - ' + unitPriceElements.length + ' precio(s) unitario(s) detectado(s)');
        }
    }

    /**
     * Ejecutar cuando el DOM esté listo
     */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initParquetPrices);
    } else {
        initParquetPrices();
    }

    /**
     * Re-inicializar si hay cambios dinámicos (AJAX, etc.)
     */
    if (typeof prestashop !== 'undefined') {
        prestashop.on('updatedProduct', function() {
            initParquetPrices();
        });
    }

})();
