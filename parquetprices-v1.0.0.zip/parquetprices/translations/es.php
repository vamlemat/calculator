<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{parquetprices}prestashop>parquetprices_'] = 'Parquet Prices Display';
$_MODULE['<{parquetprices}prestashop>parquetprices_description'] = 'Muestra el precio unitario (€/m²) como precio principal en productos con unidad de medida';
$_MODULE['<{parquetprices}prestashop>package-price-secondary_price_label'] = 'Precio por paquete:';
