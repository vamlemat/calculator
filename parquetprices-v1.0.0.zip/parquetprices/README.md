# 📐 Parquet Prices Display - Módulo para PrestaShop

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![PrestaShop](https://img.shields.io/badge/PrestaShop-1.8.2+-green.svg)
![License](https://img.shields.io/badge/license-AFL--3.0-orange.svg)
![Author](https://img.shields.io/badge/author-ATECH-purple.svg)

## 📋 Descripción

**Parquet Prices Display** es un módulo profesional para PrestaShop diseñado específicamente para **tiendas del sector del parquet y revestimientos**. Invierte la visualización de precios para mostrar el **precio unitario (€/m²)** como precio principal, en lugar del precio del paquete.

### 🎯 Problema que Resuelve

Por defecto, PrestaShop muestra:

```
❌ 41,17 €          ← Precio del paquete (principal)
   25,80 € m²       ← Precio unitario (secundario)
```

Con este módulo, los clientes verán:

```
✅ 25,80 € m²       ← Precio unitario (principal)
   41,17 € paquete  ← Precio del paquete (secundario)
```

Esto es **fundamental para el sector del parquet**, donde los clientes piensan en m² y necesitan ver ese precio de forma destacada.

---

## ✨ Características Principales

- 🔄 **Inversión automática de precios**: Muestra €/m² como precio principal
- 🏠 **Enfocado en parquet**: Diseñado para el sector de revestimientos y suelos
- 🎨 **Compatible con Warehouse**: Funciona perfectamente con el tema Warehouse
- 🔧 **Plug & Play**: Instalar y listo, sin configuración compleja
- 🌍 **Formato español**: Precios con coma decimal (25,80 €)
- 📱 **Responsive**: Diseño adaptado a móviles y tablets
- ⚡ **Ligero y rápido**: Sin impacto en el rendimiento
- 🛡️ **Manejo inteligente**: Si un producto no tiene unidad, muestra precio normal

---

## 🚀 Instalación

### Requisitos Previos

Asegúrate de que tus productos tienen configurado:

1. **Precio por unidad** en la ficha del producto
2. **Unidad de medida** (m², ml, etc.)

En PrestaShop:
- Backoffice > Catálogo > Productos > [Tu Producto]
- Pestaña **"Precios"**
- Sección **"Precio unitario"**

---

### Instalación del Módulo

#### Método 1: Desde el Back-Office (Recomendado)

1. Descarga `parquetprices-v1.0.0.zip` desde [releases](https://github.com/vamlemat/parquet-prices-display/releases)
2. En PrestaShop, ve a **Módulos > Module Manager**
3. Haz clic en **"Subir un módulo"**
4. Selecciona el archivo ZIP
5. El módulo se instalará automáticamente
6. ¡Listo! Ya funciona

#### Método 2: Por FTP

1. Descomprime el ZIP
2. Sube la carpeta `parquetprices` a `/modules/` en tu servidor
3. Ve a **Módulos > Module Manager**
4. Busca "Parquet Prices Display"
5. Haz clic en **"Instalar"**

---

## ⚙️ Configuración

### ¡No Requiere Configuración!

El módulo funciona automáticamente después de la instalación. Simplemente:

1. **Instala el módulo**
2. **Asegúrate de que tus productos tienen precio unitario configurado**
3. **¡Funciona!**

### Verificar que Funciona

1. Ve a la ficha de un producto con precio unitario
2. Deberías ver:
   ```
   25,80 € m²          ← Grande y destacado
   Precio por paquete: 41,17 €   ← Más pequeño, debajo
   ```

---

## 🎯 ¿Cómo Funciona?

### Lógica del Módulo

```
SI el producto tiene:
   - Precio unitario configurado (> 0)
   - Unidad de medida definida (m², ml, etc.)
ENTONCES:
   ✓ Mostrar precio unitario como principal
   ✓ Mostrar precio del paquete como secundario
SINO:
   ✓ Mostrar precio normal de PrestaShop
```

### Productos sin Precio Unitario

El módulo es inteligente:
- ❌ **Sin precio unitario** → Muestra precio normal
- ✅ **Con precio unitario** → Invierte la visualización

Esto significa que puedes tener productos con y sin unidad en la misma tienda.

---

## 📋 Casos de Uso

### Perfecto Para:

- 🏠 **Tiendas de parquet** (m²)
- 🎨 **Pinturas y barnices** (litros, m²)
- 🧱 **Materiales de construcción** (m², kg)
- 🌿 **Césped artificial** (m²)
- 🛠️ **Revestimientos** (m², ml)
- 📦 **Cualquier producto vendido por unidad de medida**

### Ejemplo Real

**Producto**: Parquet Roble Natural

**Configuración en PrestaShop:**
- Precio: 41,17 € (precio del paquete)
- Precio unitario: 25,80 €
- Unidad: m²
- Contenido del paquete: 1,60 m²

**Lo que ve el cliente:**
```
╔══════════════════════════════════╗
║  Parquet Roble Natural          ║
║                                  ║
║  25,80 € m²                     ║ ← Principal (grande)
║  Precio por paquete: 41,17 €    ║ ← Secundario
║                                  ║
║  [Añadir al carrito]            ║
╚══════════════════════════════════╝
```

---

## 🎨 Personalización

### CSS Personalizado

Puedes personalizar los estilos editando `/views/css/front.css`:

```css
/* Cambiar tamaño del precio unitario */
.parquet-unit-price-main {
    font-size: 2.5em; /* Por defecto: 2em */
}

/* Cambiar color del precio */
.parquet-unit-price-main .price-value {
    color: #27ae60; /* Verde en lugar de rojo */
}

/* Ajustar texto secundario */
.parquet-package-price-secondary {
    font-size: 1.1em;
    color: #34495e;
}
```

### Modificar Textos

Edita `/translations/es.php` para cambiar los textos:

```php
$_MODULE['<{parquetprices}prestashop>package-price-secondary_price_label'] = 'Paquete completo:';
```

---

## 🔧 Hooks Utilizados

El módulo utiliza los siguientes hooks de PrestaShop:

| Hook | Propósito |
|------|-----------|
| `header` | Cargar CSS y JavaScript |
| `displayProductPriceBlock` | Modificar visualización de precios |
| `actionFrontControllerSetVariables` | Inyectar variables en templates |

---

## 📦 Estructura del Módulo

```
parquetprices/
├── parquetprices.php          # Módulo principal
├── config.xml                  # Configuración
├── logo.png                    # Logo del módulo
├── index.php                   # Seguridad
├── README.md                   # Esta documentación
│
├── translations/
│   ├── es.php                 # Traducciones español
│   └── index.php
│
└── views/
    ├── css/
    │   ├── front.css          # Estilos frontend
    │   └── index.php
    ├── js/
    │   ├── front.js           # JavaScript
    │   └── index.php
    └── templates/
        └── hook/
            ├── unit-price-main.tpl         # Precio unitario
            ├── package-price-secondary.tpl # Precio paquete
            └── index.php
```

---

## 🐛 Solución de Problemas

### El módulo no muestra nada

**Causas posibles:**

1. ✅ **El producto no tiene precio unitario configurado**
   - Solución: Configura "Precio por unidad" en la ficha del producto

2. ✅ **El precio unitario es 0**
   - Solución: El módulo solo actúa si el precio unitario es > 0

3. ✅ **No has definido la unidad (m², ml, etc.)**
   - Solución: Define la "Unidad" en la configuración del producto

4. ✅ **Caché activa**
   - Solución: Limpia la caché de PrestaShop (Configuración > Rendimiento)

---

### Los precios no se ven bien

1. **Conflicto con el tema**
   - Solución: Ajusta los estilos en `/views/css/front.css`

2. **Otro módulo interfiere**
   - Solución: Desactiva otros módulos de precio temporalmente para identificar conflictos

---

### Compatibilidad con otros módulos

**✅ Compatible con:**
- Calculator (módulo de calculadora)
- Módulos de descuento
- Módulos de promociones
- Temas estándar de PrestaShop

**⚠️ Puede requerir ajustes con:**
- Módulos que modifiquen completamente la estructura de precios
- Temas muy personalizados

---

## 📋 Requisitos Técnicos

| Componente | Versión Mínima | Recomendada |
|------------|----------------|-------------|
| **PrestaShop** | 1.8.2 | 1.8.8+ |
| **PHP** | 7.1 | 7.4+ |
| **MySQL** | 5.6 | 5.7+ |
| **Tema** | Warehouse (testado) | Cualquiera |

---

## 🔄 Roadmap

### v1.0.0 (Actual)
- ✅ Inversión de precios en ficha de producto
- ✅ Compatibilidad con tema Warehouse
- ✅ Formato español
- ✅ Manejo inteligente de productos sin unidad

### v1.1.0 (Próximamente)
- 📋 Soporte para listado de productos
- 📋 Soporte para resultados de búsqueda
- 📋 Configuración avanzada desde backoffice

### v2.0.0 (Futuro)
- 📋 Soporte para categorías completas
- 📋 Múltiples formatos de precio
- 📋 Plantillas personalizables desde backoffice

---

## 🤝 Contribuir

Las contribuciones son bienvenidas! Si quieres mejorar el módulo:

1. Haz un fork del repositorio
2. Crea una rama (`git checkout -b feature/MiMejora`)
3. Commit tus cambios (`git commit -m 'Añadir MiMejora'`)
4. Push a la rama (`git push origin feature/MiMejora`)
5. Abre un Pull Request

---

## 📝 Changelog

### [1.0.0] - 2025-11-20

#### ✨ Inicial
- Inversión de precios (unitario como principal)
- Compatibilidad con tema Warehouse
- Formato español de números
- Manejo inteligente de productos sin unidad
- CSS y JS optimizados
- Documentación completa

---

## 📄 Licencia

Este proyecto está licenciado bajo la **Academic Free License (AFL 3.0)**.

---

## 👤 Autor

**ATECH**

---

## 🔗 Enlaces

- 📦 [Releases](https://github.com/vamlemat/parquet-prices-display/releases)
- 🐛 [Reportar un Bug](https://github.com/vamlemat/parquet-prices-display/issues)
- 💡 [Solicitar Funcionalidad](https://github.com/vamlemat/parquet-prices-display/issues/new)

---

## ⭐ Agradecimientos

Gracias por usar Parquet Prices Display! Si este módulo te ha sido útil:

- ⭐ Dale una estrella al repositorio
- 🐛 Reporta bugs y sugiere mejoras
- 📢 Comparte con otros usuarios del sector

---

**¿Preguntas o necesitas soporte?** Abre un [issue en GitHub](https://github.com/vamlemat/parquet-prices-display/issues) 😊

---

## 💼 Desarrollo Profesional

Este módulo ha sido desarrollado profesionalmente para **ATECH** con las mejores prácticas de PrestaShop y pensando específicamente en las necesidades del sector del parquet y revestimientos.
