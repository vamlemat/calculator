<?php
/**
 * Parquet Prices Display
 *
 * @author    ATECH
 * @copyright 2025 ATECH
 * @license   AFL-3.0
 * @version   1.0.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class ParquetPrices extends Module
{
    public function __construct()
    {
        $this->name = 'parquetprices';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'ATECH';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Parquet Prices Display');
        $this->description = $this->l('Muestra el precio unitario (€/m²) como precio principal en productos con unidad de medida');
        $this->ps_versions_compliancy = array('min' => '1.8.2', 'max' => _PS_VERSION_);
    }

    /**
     * Instalación del módulo
     */
    public function install()
    {
        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('displayProductPriceBlock') &&
            $this->registerHook('actionFrontControllerSetVariables');
    }

    /**
     * Desinstalación del módulo
     */
    public function uninstall()
    {
        return parent::uninstall();
    }

    /**
     * Cargar CSS y JS en el frontend
     */
    public function hookHeader()
    {
        $this->context->controller->addCSS($this->_path . 'views/css/front.css');
        $this->context->controller->addJS($this->_path . 'views/js/front.js');
    }

    /**
     * Hook principal para modificar visualización de precios
     * Se ejecuta en diferentes puntos de la visualización del producto
     */
    public function hookDisplayProductPriceBlock($params)
    {
        if (!isset($params['product']) || !isset($params['type'])) {
            return;
        }

        $product = $params['product'];
        
        // Solo actuamos si el producto tiene precio unitario
        if (!$this->hasUnitPrice($product)) {
            return;
        }

        // Preparar datos para la plantilla
        $this->context->smarty->assign($this->getProductPriceData($product));

        // Según el tipo de bloque, mostramos diferentes cosas
        switch ($params['type']) {
            case 'before_price':
                // Aquí se muestra el precio unitario como principal
                return $this->display(__FILE__, 'views/templates/hook/unit-price-main.tpl');
            
            case 'after_price':
                // Aquí se muestra el precio del paquete como secundario
                return $this->display(__FILE__, 'views/templates/hook/package-price-secondary.tpl');
            
            default:
                return;
        }
    }

    /**
     * Inyectar variables en el template del producto
     */
    public function hookActionFrontControllerSetVariables($params)
    {
        if (isset($params['templateVars']['product'])) {
            $product = $params['templateVars']['product'];
            
            if ($this->hasUnitPrice($product)) {
                $priceData = $this->getProductPriceData($product);
                $params['templateVars']['parquet_prices'] = $priceData;
            }
        }
    }

    /**
     * Verifica si el producto tiene precio unitario configurado
     */
    private function hasUnitPrice($product)
    {
        // Verificar si es array o objeto
        if (is_array($product)) {
            return isset($product['unit_price']) && 
                   !empty($product['unit_price']) && 
                   $product['unit_price'] > 0 &&
                   isset($product['unity']) &&
                   !empty($product['unity']);
        } else {
            return isset($product->unit_price) && 
                   !empty($product->unit_price) && 
                   $product->unit_price > 0 &&
                   isset($product->unity) &&
                   !empty($product->unity);
        }
    }

    /**
     * Obtiene los datos de precio formateados para mostrar
     */
    private function getProductPriceData($product)
    {
        // Manejar tanto arrays como objetos
        if (is_array($product)) {
            $unitPrice = $product['unit_price'];
            $unity = $product['unity'];
            $price = $product['price'];
            $priceAmount = isset($product['price_amount']) ? $product['price_amount'] : $price;
        } else {
            $unitPrice = $product->unit_price;
            $unity = $product->unity;
            $price = $product->price;
            $priceAmount = isset($product->price_amount) ? $product->price_amount : $price;
        }

        return array(
            'unit_price' => $unitPrice,
            'unit_price_formatted' => $this->formatPrice($unitPrice),
            'unity' => $unity,
            'package_price' => $priceAmount,
            'package_price_formatted' => $this->formatPrice($priceAmount),
            'has_unit_price' => true,
        );
    }

    /**
     * Formatea el precio en español (coma decimal, punto miles)
     */
    private function formatPrice($price)
    {
        // Usar el contexto de PrestaShop para formatear correctamente
        return Tools::displayPrice($price);
    }

    /**
     * Página de configuración (por si necesitamos opciones en el futuro)
     */
    public function getContent()
    {
        $output = '<div class="alert alert-info">';
        $output .= '<h4>' . $this->l('Módulo Parquet Prices Display') . '</h4>';
        $output .= '<p>' . $this->l('Este módulo automáticamente muestra el precio unitario (€/m²) como precio principal en productos con unidad de medida configurada.') . '</p>';
        $output .= '<p><strong>' . $this->l('¿Cómo funciona?') . '</strong></p>';
        $output .= '<ul>';
        $output .= '<li>' . $this->l('Si el producto tiene "Precio por unidad" configurado → muestra ese precio primero') . '</li>';
        $output .= '<li>' . $this->l('El precio del paquete se muestra como secundario') . '</li>';
        $output .= '<li>' . $this->l('Si no tiene precio unitario → muestra el precio normal') . '</li>';
        $output .= '</ul>';
        $output .= '<p><strong>' . $this->l('Compatible con:') . '</strong> Tema Warehouse, PrestaShop 1.8.2+</p>';
        $output .= '</div>';

        return $output;
    }
}
